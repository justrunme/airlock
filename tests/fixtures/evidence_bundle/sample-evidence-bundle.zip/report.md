# app.log report

```airlock-counts
ERROR: 31
WARN: 8
```

## Errors by message
- 18 x upstream connect error
